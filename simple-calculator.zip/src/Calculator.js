import React, { useState } from "react";
import "./Calculator.css";

const Calculator = () => {
  const [input, setInput] = useState("");

  const appendNum = (value) => {
    setInput(input + value);
  };

  const clearDisplay = () => {
    setInput("");
  };

  const deleteElement = () => {
    setInput(input.slice(0, -1));
  };

  const answer = () => {
    try {
      setInput(eval(input).toString());
    } catch (e) {
      setInput("Error");
    }
  };

  return (
    <div className="calculator">
      <input type="text" value={input} readOnly className="calculator-screen" />
      <div className="calculator-buttons">
        <button onClick={() => appendNum("7")}>7</button>
        <button onClick={() => appendNum("8")}>8</button>
        <button onClick={() => appendNum("9")}>9</button>
        <button onClick={() => appendNum("/")}>/</button>
        <button onClick={() => appendNum("4")}>4</button>
        <button onClick={() => appendNum("5")}>5</button>
        <button onClick={() => appendNum("6")}>6</button>
        <button onClick={() => appendNum("*")}>*</button>
        <button onClick={() => appendNum("1")}>1</button>
        <button onClick={() => appendNum("2")}>2</button>
        <button onClick={() => appendNum("3")}>3</button>
        <button onClick={() => appendNum("-")}>-</button>
        <button onClick={() => appendNum("0")}>0</button>
        <button onClick={() => appendNum("+")}>+</button>
        <button onClick={deleteElement}>Del</button>
        <button onClick={clearDisplay}>C</button>
        <button onClick={answer}>=</button>

      </div>
    </div>
  );
};

export default Calculator;
